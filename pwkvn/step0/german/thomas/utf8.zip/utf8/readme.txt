german
 check German spelling in pwkvn

======================================================================
German word list 
https://gist.github.com/MarvinJWendt/2f4f4154b8ae218600eb091a5706b5f4/raw/36b70dd6be330aa61cd4d4cdfda6234dcb0b8784/wordlist-german.txt

1908815 words
======================================================================
examine italic text in pwkv7. 
gtext1_known.txt   (7058) italic words IN the German word list
gtext1_unknown.txt (2963) italic words NOT IN the German word list
   examine these unknowns further
======================================================================

pwkvn_german_unknown.txt  (2963) view in Google Docs.
  put 'x' in those lines identified (by red underline) by Spell Check/
  1093 are marked with 'x'

======================================================================
unknown_x.txt (1093)
 just the lines of pwkvn_german_unknown.txt starting with 'x'

unknown_x_num.txt  (1093) same as unknown_x except with sequence number.

unknown_x_eng.txt (1093) Apply Google Translate to unknown_x_num.txt.
=====================================

unknown_merge.txt (1093)  merge unknown_x_num.txt and unknown_x_eng.txt .

=====================================
gtext3.txt (1345 records)
 Lines of pwkvn containing any of the German words in unknown_merge.txt.
 Each pwkvn line is shown as 'old' and 'new'
 Changes may be made to the 'new' lines.
 Any such changes can then be reinserted into latest pwkvn file.
 
 

